package com.salada.api;

public interface InterfazComponente {
public String getComponente();

}
